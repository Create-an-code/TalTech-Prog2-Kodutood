One number in list leetcode confirmation 
![image](https://github.com/Create-an-code/TalTech-Prog2-Kodutood/assets/159798754/5c89c767-ce1f-489d-a336-c4b1842d5867)
